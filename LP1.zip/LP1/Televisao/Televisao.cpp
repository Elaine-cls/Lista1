#include "Televisao.h"

Televisao::Televisao(int c, int v)
{
    canal = c;
    volume = v;
}

Televisao::Televisao()
{

}

void Televisao::setCanal(int c)
{
    if(canal<=0  || canal >= 100){

        canal = 1;
       }else{
        canal = c;
       }
}
int Televisao::getCanal()
{
        return canal;
}
void Televisao::setVolume(int v)
{
    if(volume<=0){
        volume = 0;

      }else if( volume>=100){

        volume = 100;
         }else{

          volume= v;
     }
}

int Televisao::getVolume()
{
        return volume;
}

void Televisao::incrementaCanal()
{
    if(canal >= 99){
        canal = 1;
    }else{
        canal++;
    }
}

void Televisao::decrementaCanal()
{
    if(canal >= 0){
        canal = 99;
    }else{
        canal--;
    }
}

void Televisao::incrementaVolume()
{
    if(volume >= 99){
        volume = 100;
    }else{
        volume++;
    }
}
void Televisao::decrementaVolume()
{
    if(volume <= 0){
        volume = 99;
    }else{
        volume--;
    }
}

Televisao::~Televisao()
{
    //dtor
}
