#ifndef TELEVISAO_H
#define TELEVISAO_H


class Televisao
{
    private:
        int canal;
        int volume;

    public:
        Televisao();
        Televisao(int canal, int volume);
        void setCanal(int c);
        int getCanal();
        void setVolume(int v);
        int getVolume();
        void incrementaCanal();
        void decrementaCanal();
        void incrementaVolume();
        void decrementaVolume();


        virtual ~Televisao();

};

#endif // TELEVISAO_H
