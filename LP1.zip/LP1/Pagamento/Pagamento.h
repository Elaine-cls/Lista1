#ifndef PAGAMENTO_H
#define PAGAMENTO_H
#include <string>


class Pagamento
{
    private:
    double valorPagamento;
    std::string nomeDoFuncionario;

    public:
        Pagamento(double v, std::string n);
        Pagamento();
        void setValorPagamento(double v);
        double getValorPagamento();
        void setNomeDoFuncionario(std::string n);
        std::string getNomeDoFuncionario();


};

#endif // PAGAMENTO_H
