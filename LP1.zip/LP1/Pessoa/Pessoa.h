#ifndef PESSOA_H
#define PESSOA_H
#include <string>


class Pessoa
{
    private:
        std::string nome;
        int idade;
        int telefone;

    public:
        Pessoa1(std::string nome);
        Pessoa2(std::string nome, int idade, int telefone );
        void setNome(std::string n);
        std::string getNome();
        void setIdade(int id);
        int getIdade();
        void setTelefone(int tel);
        int getTelefone();


};

#endif // PESSOA_H
