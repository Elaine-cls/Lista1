#include <iostream>
#include "Pessoa.h"


using namespace std;

int main()
{

    Pessoa pessoa1 =  Pessoa("Danielle", 18 , 91622325);
    Pessoa pessoa2 =  Pessoa("Victoria", 17 , 99340056);



    cout << "Nome: " << pessoa1.getNome()  << endl;
    cout << "Idade: " << pessoa1.getIdade() <<  endl;
    cout << "Telefone: " << pessoa1.getTelefone() << endl;
    cout << "Nome: " << pessoa2.getNome() << endl;
    cout << "Idade: " << pessoa2.getIdade() << endl;
    cout << "Telefone: " << pessoa2.getTelefone() << endl;

    return 0;
}
