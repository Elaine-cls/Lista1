#include "Relogio.h"

Relogio::Relogio(int h, int m, int s)
{
    hora = h;
    minuto = m;
    segundo = s;
}

Relogio::Relogio()
{

}

void Relogio::setHorario(int hora, int minuto, int segundo)
{
       if(segundo>= 60){
        segundo-=60;
        minuto += 1;
       }

       if(minuto >= 60){

        minuto-=60;
        hora+=1;
       }

       if(hora>=24){

        hora = hora;
        minuto = minuto;
        segundo = segundo;
    }
}

int Relogio::getHora()
{
    return hora;
}

int Relogio::getMinuto()
{
    return minuto;
}

int Relogio::getSegundo(){
    return segundo;
}

void Relogio::avancarHorario(){


     segundo+=1;

     if(segundo>=60)

     {

               segundo-=60;

               minuto+=1;

     }

     if(minuto>=60)

     {

               minuto-=60;

               hora+=1;

     }

     if(hora>=24){

               hora-=24;

}


}
Relogio::~Relogio()
{
    //dtor
}
