#ifndef RELOGIO_H
#define RELOGIO_H


class Relogio
{
    private:
        int hora;
        int minuto;
        int segundo;

    public:
        Relogio();
        Relogio(int hora, int minuto, int segundo);
        void setHorario(int hora, int minuto, int segundo);
        int getHora();
        int getMinuto();
        int getSegundo();
        void avancarHorario();
        virtual ~Relogio();




};

#endif // RELOGIO_H
